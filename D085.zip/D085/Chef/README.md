# learn_chef_httpd

This basic cookbook configures Apache on Red Hat Enterprise Linux.
